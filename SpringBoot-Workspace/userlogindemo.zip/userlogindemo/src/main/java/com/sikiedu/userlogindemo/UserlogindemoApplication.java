package com.sikiedu.userlogindemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserlogindemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserlogindemoApplication.class, args);
	}
}
