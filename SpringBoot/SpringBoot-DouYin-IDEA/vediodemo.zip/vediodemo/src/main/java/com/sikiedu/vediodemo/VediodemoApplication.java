package com.sikiedu.vediodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VediodemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VediodemoApplication.class, args);
	}
}
